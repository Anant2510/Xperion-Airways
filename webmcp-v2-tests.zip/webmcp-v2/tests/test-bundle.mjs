// Boot the REAL built bundle (public/v2/app.js) in a DOM against a live server,
// then drive it the way an in-browser agent would: discover the registered
// tools via document.modelContext, call them, and assert the page reacted.
//
// This is the closest thing to the Chrome test that does not need Chrome. It
// catches what the module-level test cannot: that the tools survive bundling,
// that installWebMCP() actually runs from main.jsx's effect, and that React
// re-renders when trip.js notifies.

import fs from "node:fs";
import path from "node:path";
import { createRequire } from "node:module";

// Run from the repo root, or set REPO=/path/to/Tap-demo.
const REPO = process.env.REPO || process.cwd();
const BASE = process.env.BASE || "http://127.0.0.1:7999";
const BUNDLE = path.join(REPO, "public/v2/app.js");

if (!fs.existsSync(BUNDLE)) {
  console.error(`No public/v2/app.js under ${REPO}. Run npm run build:v2 first.`);
  process.exit(2);
}

// Resolve jsdom from the repo's own node_modules, not from wherever this test sits.
let JSDOM;
try {
  ({ JSDOM } = createRequire(path.join(REPO, "package.json"))("jsdom"));
} catch {
  console.error("jsdom not installed. Run:  npm i --no-save jsdom");
  process.exit(2);
}

let pass = 0, fail = 0;
const ok = (cond, label, detail = "") => {
  if (cond) { pass++; console.log(`  ✓ ${label}`); }
  else { fail++; console.log(`  ✗ ${label}${detail ? "  → " + detail : ""}`); }
};

/* ── a DOM with a WebMCP host on it ──────────────────────────────────────── */
const dom = new JSDOM(
  `<!doctype html><html><body><div id="root"></div></body></html>`,
  { url: BASE + "/v2/", pretendToBeVisual: true, runScripts: "outside-only" }
);
const { window } = dom;

const registered = new Map();
window.document.modelContext = {
  registerTool(t) {
    if (registered.has(t.name)) throw new Error(`duplicate tool ${t.name}`);
    registered.set(t.name, t);
  },
  unregisterTool(n) { registered.delete(n); },
  provideContext(tools) { registered.clear(); (tools || []).forEach(t => registered.set(t.name, t)); },
};

// Relative fetches need an absolute origin in jsdom.
window.fetch = (url, init) =>
  fetch(typeof url === "string" && url.startsWith("/") ? BASE + url : url, init);
window.requestAnimationFrame = (cb) => setTimeout(() => cb(Date.now()), 0);
window.scrollTo = () => {};
window.matchMedia = window.matchMedia || (() => ({ matches: false, addEventListener() {}, removeEventListener() {} }));

/* ── run the bundle ──────────────────────────────────────────────────────── */
console.log("\n── 1. the built bundle boots ────────────────────────────────");
let bootError = null;
try {
  dom.window.eval(fs.readFileSync(BUNDLE, "utf8"));
} catch (e) { bootError = e; }
ok(!bootError, "public/v2/app.js executes without throwing", bootError?.message);

// installWebMCP() fetches the contract, so registration is async.
const waitFor = async (fn, ms = 8000) => {
  const t0 = Date.now();
  while (Date.now() - t0 < ms) { if (fn()) return true; await new Promise(r => setTimeout(r, 100)); }
  return false;
};
const registeredInTime = await waitFor(() => registered.size >= 27);
ok(registeredInTime, "main.jsx's effect registered the contract", `${registered.size} tools`);
ok(!!window.__tapTools, "console handle exposed for flag-less demoing");

console.log("\n── 2. React mounted and renders ─────────────────────────────");
const root = window.document.getElementById("root");
ok((root?.innerHTML || "").length > 500, "app rendered into #root", `${root?.innerHTML?.length || 0} chars`);

console.log("\n── 3. an agent drives the page ──────────────────────────────");
const call = async (name, input = {}) => {
  const t = registered.get(name);
  if (!t) return { isError: true, content: [{ type: "text", text: `${name} not registered` }] };
  return t.execute(input);
};
const data = (r) => {
  if (r.isError) return { _error: r.content[0].text };
  try { return JSON.parse(r.content[0].text); } catch { return { _unparseable: r.content[0].text }; }
};

const search = data(await call("search_flights", { origin: "OPO", dest: "LIS", date: "2026-09-04" }));
ok(search.ok === true, "agent ran search_flights through the bundle", search._error);
ok(Array.isArray(search.flights) && search.flights.length > 0, "flights returned",
   String(search.flights?.length));
ok(window.location.hash.startsWith("#/results"), "the page navigated to results",
   window.location.hash);

const flightNo = search.flights[0].flight_no;
const sel = data(await call("select_flight", { flight_no: flightNo }));
ok(sel.ok === true, "agent selected a flight", sel._error);
ok(window.location.hash === "#/cart", "the page navigated to the cart", window.location.hash);

console.log("\n── 4. the basket is the SAME basket the UI reads ────────────");
// trip.js mirrors itself to localStorage on every notify(). If the agent's
// add_extras had written only to the server session, this would not change —
// which is exactly the split ai.jsx has today.
const readTrip = () => { try { return JSON.parse(window.localStorage.getItem("flytap_trip") || "{}"); } catch { return {}; } };
const beforeCodes = (readTrip().extras || []).map(e => e.code);
const add = data(await call("add_extras", { codes: ["lounge", "wifi"] }));
ok(add.ok === true, "agent ran add_extras", add._error);
await new Promise(r => setTimeout(r, 150));
const afterCodes = (readTrip().extras || []).map(e => e.code);
ok(afterCodes.includes("lounge"), "the client basket contains the agent's extra",
   `${beforeCodes.join(",")} → ${afterCodes.join(",")}`);
ok(readTrip().outbound?.flight?.flight_no === flightNo,
   "the persisted trip holds the agent's flight", String(readTrip().outbound?.flight?.flight_no));

const rm = data(await call("remove_extras", { codes: ["lounge"] }));
ok(rm.ok === true, "agent ran remove_extras", rm._error);
await new Promise(r => setTimeout(r, 150));
ok(!(readTrip().extras || []).some(e => e.code === "lounge"), "removal reached the client basket",
   (readTrip().extras || []).map(e => e.code).join(","));

console.log("\n── 5. safety holds inside the bundle ────────────────────────");
const sneaky = await call("cancel_booking", { confirm: true });
ok(sneaky.isError === true, "confirm=true without a prior ask is refused");
const co = data(await call("checkout", {}));
ok(co.state === "needs_confirm", "checkout asks before charging", JSON.stringify(co).slice(0, 90));

console.log("\n── 5b. seat navigation is context-aware ─────────────────────");
// A cart is in progress, so the seat picker is the cart's Seats & baggage module.
// #/seatchange is the POST-booking screen (useActiveBooking) and would show a
// different journey than the one the agent just built.
await call("list_seats", {});
ok(window.location.hash === "#/cart", "with a cart open, list_seats stays in the cart",
   window.location.hash);

console.log("\n── 5c. seat-map screen tools ────────────────────────────────");
// The screen registers these from its own effect; nothing is published while the
// map is closed, which is the point of scoping them.
ok(window.__tapTools.screenList().length === 0,
   "no seat-map tools published while the map is closed",
   window.__tapTools.screenList().join(","));
const closed = await window.__tapTools.screen("pick_seat_on_map", { seat: "22A" })
  .then(() => null).catch(e => e.message);
ok(!!closed, "calling a screen tool while its screen is closed rejects", String(closed));

console.log("\n── 6. tool coverage through the bundle ──────────────────────");
ok(registered.size === 27, "27 tools published", String(registered.size));
const names = [...registered.keys()].sort();
ok(names.includes("resolve_disruption") && names.includes("split_booking") && names.includes("express_usual"),
   "the long-tail servicing tools are published too");

console.log(`\n${"─".repeat(60)}\n  ${pass} passed, ${fail} failed\n`);
dom.window.close();
process.exit(fail ? 1 : 0);
