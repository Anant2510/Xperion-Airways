// End-to-end test for web/v2/webmcp.js.
//
// Loads the REAL trip.js and lib.js modules and the REAL webmcp.js against a
// live server, so this exercises the actual projection logic rather than a
// mock of it. Only the browser globals are shimmed: localStorage, a
// window/location with a hash, and document.modelContext.

import fs from "node:fs";
import os from "node:os";
import path from "node:path";

// Run from the repo root, or set REPO=/path/to/Tap-demo.
const REPO = process.env.REPO || process.cwd();
const BASE = process.env.BASE || "http://127.0.0.1:7999";

if (!fs.existsSync(path.join(REPO, "web/v2/webmcp.js"))) {
  console.error(`No web/v2/webmcp.js under ${REPO}.\nRun this from the repo root, or set REPO=/path/to/Tap-demo.`);
  process.exit(2);
}

/* ── browser shims ───────────────────────────────────────────────────────── */
const store = new Map();
globalThis.localStorage = {
  getItem: k => (store.has(k) ? store.get(k) : null),
  setItem: (k, v) => store.set(k, String(v)),
  removeItem: k => store.delete(k),
};

const registered = new Map();
const navLog = [];
globalThis.window = {
  get location() { return globalThis.location; },
  set location(v) { globalThis.location = v; },
};
globalThis.location = {
  _hash: "",
  get hash() { return this._hash; },
  set hash(v) { this._hash = v; navLog.push(v); },
};
globalThis.window.location = globalThis.location;
globalThis.document = {
  modelContext: {
    registerTool(t) {
      if (registered.has(t.name)) throw new Error(`duplicate tool ${t.name}`);
      if (!t.name || !t.description || !t.inputSchema) throw new Error(`incomplete tool ${t.name}`);
      registered.set(t.name, t);
    },
    unregisterTool(n) { registered.delete(n); },
  },
};

// lib.js builds URLs as `/api` + path; give fetch an absolute base.
const realFetch = globalThis.fetch;
globalThis.fetch = (url, init) =>
  realFetch(typeof url === "string" && url.startsWith("/") ? BASE + url : url, init);

/* ── load the real modules ───────────────────────────────────────────────── */
// web/v2/*.js are ESM, but the repo's package.json is type:commonjs (esbuild
// doesn't care; node does). Copy the three modules to a scratch dir carrying
// {"type":"module"} so node loads the real, unmodified source as ESM.
const V2 = fs.mkdtempSync(path.join(os.tmpdir(), "tapv2-")) + path.sep;
for (const f of ["trip.js", "lib.js", "webmcp.js"]) {
  fs.copyFileSync(path.join(REPO, "web/v2", f), V2 + f);
}
fs.writeFileSync(V2 + "package.json", '{"type":"module"}');

const { trip } = await import(V2 + "trip.js");
const { authReady } = await import(V2 + "lib.js");
const webmcp = await import(V2 + "webmcp.js");
authReady();   // open lib.js's boot gate; no login flow in this harness

/* ── assertions ──────────────────────────────────────────────────────────── */
let pass = 0, fail = 0;
const ok = (cond, label, detail = "") => {
  if (cond) { pass++; console.log(`  ✓ ${label}`); }
  else { fail++; console.log(`  ✗ ${label}${detail ? "  → " + detail : ""}`); }
};
const call = async (name, input) => {
  const t = registered.get(name);
  if (!t) return { isError: true, content: [{ type: "text", text: "not registered" }] };
  return t.execute(input || {});
};
const data = (res) => {
  if (res.isError) return { _error: res.content[0].text };
  try { return JSON.parse(res.content[0].text); } catch { return { _unparseable: true }; }
};

/* ── run ─────────────────────────────────────────────────────────────────── */
console.log("\n── 1. registration ──────────────────────────────────────────");
await webmcp.installWebMCP();
ok(registered.size === 27, `27 tools registered`, `got ${registered.size}`);
ok(registered.has("search_flights") && registered.has("cancel_booking"), "contract tools present");
ok([...registered.values()].every(t => t.inputSchema?.type === "object"), "every tool has an object schema");
ok(registered.get("checkout").inputSchema.properties.confirm?.type === "boolean",
   "checkout schema advertises the client-side confirm flag");
await webmcp.installWebMCP();
ok(registered.size === 27, "install is idempotent");

console.log("\n── 2. search projects onto trip + navigates ─────────────────");
const s = data(await call("search_flights", { origin: "OPO", dest: "LIS", date: "2026-09-04" }));
ok(s.ok === true, "search_flights ok", s._error);
ok(trip.origin === "OPO" && trip.dest === "LIS", "trip.origin/dest updated", `${trip.origin}/${trip.dest}`);
ok(trip.date === "2026-09-04", "trip.date updated", String(trip.date));
ok(navLog.at(-1)?.startsWith("#/results"), "navigated to results", navLog.at(-1));
ok(s._ui?.navigated_to === "results", "result reports the navigation");

console.log("\n── 3. select_flight fills the cart ──────────────────────────");
const flightNo = s.flights[0].flight_no;
const sel = data(await call("select_flight", { flight_no: flightNo }));
ok(sel.ok === true, "select_flight ok", sel._error);
ok(trip.outbound?.flight?.flight_no === flightNo, "trip.outbound set from the tool result",
   JSON.stringify(trip.outbound?.flight?.flight_no));
ok(typeof trip.outbound?.price === "number", "outbound priced");
ok(navLog.at(-1) === "#/cart", "navigated to cart", navLog.at(-1));

console.log("\n── 4. extras sync the client basket ─────────────────────────");
const before = trip.extras.length;
const add = data(await call("add_extras", { codes: ["lounge", "wifi"] }));
ok(add.ok === true, "add_extras ok", add._error);
ok(trip.extras.length >= before, "trip.extras grew", `${before} → ${trip.extras.length}`);
ok(trip.extras.some(e => e.code === "lounge"), "lounge is in the client basket",
   trip.extras.map(e => e.code).join(","));
ok(trip.extras.every(e => e.cat && e.source), "extras keep cat/source for the UI groupings");

const rm = data(await call("remove_extras", { codes: ["lounge"] }));
ok(rm.ok === true, "remove_extras ok", rm._error);
ok(!trip.extras.some(e => e.code === "lounge"), "lounge removed from the client basket",
   trip.extras.map(e => e.code).join(","));

console.log("\n── 5. seats route by context, never to Frequent Flyer ───────");
const seats = data(await call("list_seats", {}));
ok(seats.ok === true, "list_seats ok", seats._error);
// A cart is open here, so the picker is the cart's Seats & baggage module.
// #/seatchange is the post-booking screen and binds to useActiveBooking(), i.e.
// a DIFFERENT journey than the one just built.
ok(navLog.at(-1) === "#/cart", "with a cart open, list_seats stays in the cart", navLog.at(-1));
ok(navLog.at(-1) !== "#/miles", "never lands on Frequent Flyer", navLog.at(-1));
const seat = data(await call("change_seat", { preference: "window" }));
ok(seat.ok === true, "change_seat ok", seat._error);
ok(trip.seat === seat.seat, "trip.seat updated", `${trip.seat} vs ${seat.seat}`);

console.log("\n── 6. hold / park / journey ─────────────────────────────────");
const hold = data(await call("hold_fare", { duration: "48h" }));
ok(hold.ok === true, "hold_fare ok", hold._error);
ok(trip.fareHold?.flight_no === hold.flight_no, "trip.fareHold set", JSON.stringify(trip.fareHold));
const park = data(await call("park_trip", {}));
ok(park.ok === true, "park_trip ok (needs the baskets.snapshot_json migration)", park.message || park._error);
const jr = data(await call("get_journey", {}));
ok(jr.ok === true, "get_journey ok", jr._error);

console.log("\n── 7. confirmation gate ─────────────────────────────────────");
const sneaky = await call("cancel_booking", { confirm: true });
ok(sneaky.isError === true, "confirm=true is refused without a prior needs_confirm");
const step1 = data(await call("cancel_booking", { confirm: false }));
ok(step1.state === "needs_confirm", "cancel_booking asks first", JSON.stringify(step1).slice(0, 80));
const upg1 = data(await call("upgrade_cabin", { cabin: "Business" }));
ok(upg1.state === "needs_confirm", "upgrade_cabin asks first");
const upg2 = data(await call("upgrade_cabin", { cabin: "Business", confirm: true }));
ok(upg2.ok === true, "upgrade_cabin proceeds after the gate opens", upg2._error);
const upg3 = await call("upgrade_cabin", { cabin: "Business", confirm: true });
ok(upg3.isError === true, "the gate closes again after one use");

console.log("\n── 8. checkout is gated client-side ─────────────────────────");
// park_trip deliberately empties the selection ("save this and start fresh"),
// on the server and in the UI. Re-establish a live trip before checking out.
await call("search_flights", { origin: "OPO", dest: "LIS", date: "2026-09-04" });
await call("select_flight", { flight_no: flightNo });
ok(trip.outbound?.flight?.flight_no === flightNo, "selection survives a re-search",
   String(trip.outbound?.flight?.flight_no));
const co1 = data(await call("checkout", {}));
ok(co1.state === "needs_confirm", "checkout asks before charging", JSON.stringify(co1).slice(0, 100));
ok(!co1.pnr, "no booking issued on the unconfirmed call");
const co2 = data(await call("checkout", { confirm: true }));
ok(co2.ok === true && !!co2.pnr, "checkout issues a PNR once confirmed", co2._error || "");
ok(trip.pnr === co2.pnr, "trip.pnr projected", `${trip.pnr}`);
ok(navLog.at(-1) === "#/confirmation", "navigated to confirmation", navLog.at(-1));

console.log("\n── 8b. after booking, seats route to the seat-change screen ─");
// trip.pnr is set by the checkout projection, so the cart is finished and the
// post-booking screen is now the right destination.
ok(!!trip.pnr, "a booking exists", String(trip.pnr));
await call("list_seats", {});
ok(navLog.at(-1) === "#/seatchange", "post-booking, list_seats opens the seat-change screen",
   navLog.at(-1));

console.log("\n── 9. every remaining tool executes ─────────────────────────");
const covered = new Set(["search_flights", "select_flight", "add_extras", "remove_extras",
  "list_seats", "change_seat", "hold_fare", "park_trip", "get_journey",
  "cancel_booking", "upgrade_cabin", "checkout"]);
const inputs = {
  list_destinations: { origin: "OPO" },
  get_flight_info: { flight_no: flightNo },
  search_multi_city: { legs: [{ origin: "OPO", dest: "LIS", date: "2026-09-04" }, { origin: "LIS", dest: "MAD", date: "2026-09-08" }] },
  rebook_flight: { option_id: "1" },
  resolve_disruption: { resolutions: [{ passenger: "Daniel", type: "voucher" }] },
  split_booking: { passengers: ["Ana"] },
};
for (const name of registered.keys()) {
  if (covered.has(name)) continue;
  const res = await call(name, inputs[name] || {});
  const d = data(res);
  // A tool that answers "no, and here is why" is working; only a transport or
  // registration failure is a test failure.
  ok(!res.isError && d._unparseable !== true, `${name} executes`, d._error);
}

console.log("\n── 10. teardown ─────────────────────────────────────────────");
webmcp.uninstallWebMCP();
ok(registered.size === 0, "all tools unregistered", `${registered.size} left`);

console.log(`\n${"─".repeat(60)}\n  ${pass} passed, ${fail} failed\n`);
process.exit(fail ? 1 : 0);
